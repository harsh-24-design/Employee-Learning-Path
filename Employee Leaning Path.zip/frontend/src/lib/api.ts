const API_BASE_URL = 'http://127.0.0.1:8000/api';

export type UserRole = 'learner' | 'manager' | 'admin';
export type PlanMode = 'self_directed' | 'company_assigned';
export type CertificateType = 
  | 'none'
  | 'completion_certificate'
  | 'assessed_certificate'
  | 'professional_certificate'
  | 'accredited_qualification';

export interface UserProfile {
  user_id: string;
  email: string;
  name: string;
  role: UserRole;
  is_employee: boolean;
  employee_id?: string | null;
  department: string;
  created_at?: string | null;
}

export interface AuthTokenResponse {
  token: string;
  user: UserProfile;
  message: string;
}

export interface CertificateInfo {
  available: boolean;
  type: CertificateType;
  issuer: string;
  is_included_in_price: boolean;
  separate_certificate_fee: number;
  verification_url?: string | null;
  exam_requirements?: string | null;
}

export interface Lesson {
  lesson_id: string;
  title: string;
  duration_minutes: number;
  content?: string;
  module_id?: string;
  module_title?: string;
  explanation?: string;
  practical_example?: string;
  key_takeaways?: string[];
  exercise?: string;
}

export interface CourseModule {
  module_id: string;
  title: string;
  description?: string;
  lessons: Lesson[];
  quiz?: CourseQuiz;
}

export interface Course {
  course_id: string;
  title: string;
  provider: string;
  platform: string; // "Internal", "Coursera", "edX", "Udemy", "freeCodeCamp", "LinkedIn Learning"
  description?: string;
  skill: string;
  level: number;
  hours: number;
  cost: number;
  currency: string;
  pricing_model: string; // "free", "paid_one_time", "subscription"
  subscription_monthly_cost?: number | null;
  prerequisite_id?: string | null;
  is_foundation: boolean;
  source_url?: string;
  catalogue_status: string;
  source_verification_status: string; // "verified", "unconfirmed"
  last_checked_date?: string | null;
  certificate_info: CertificateInfo;
  lessons: Lesson[];
  modules?: CourseModule[];
  is_demo?: boolean;
  demo_disclaimer?: string;
}

export interface RoleCompetency {
  skill: string;
  required_proficiency: number;
}

export interface Role {
  role_name: string;
  description: string;
  prerequisites?: string[];
  relevant_resources?: string[];
  competencies: RoleCompetency[];
}

export interface Milestone {
  milestone_id: string;
  title: string;
  description: string;
  course_ids: string[];
  estimated_hours: number;
  target_date?: string | null;
  assessment_activity?: string | null;
  is_completed: boolean;
}

export interface BudgetOptionComparison {
  model_type: string;
  provider_summary: string;
  estimated_cost: number;
  estimated_months: number;
  certificate_included: boolean;
  financial_assistance_available: boolean;
  financial_assistance_details?: string | null;
}

export interface BudgetBreakdown {
  total_estimated_cost: number;
  budget_limit?: number | null;
  is_within_budget: boolean;
  free_alternatives_cost: number;
  paid_courses_cost: number;
  subscription_cost: number;
  certificate_fees_cost: number;
  staged_path_suggestion?: string | null;
  comparisons: BudgetOptionComparison[];
}

export interface LearningPlan {
  plan_id: string;
  employee_id: string;
  mode: PlanMode;
  target_role: string;
  is_custom_goal: boolean;
  goal_description?: string | null;
  current_skill_snapshot: Record<string, number>;
  target_competencies: Record<string, number>;
  ordered_courses: Course[];
  total_hours: number;
  total_cost: number;
  estimated_weeks: number;
  is_extended_timeline: boolean;
  budget_limit: number | null;
  weekly_hours: number;
  training_intensity: string;
  target_completion_date?: string | null;
  milestones: Milestone[];
  budget_breakdown?: BudgetBreakdown | null;
  remaining_gaps: string[];
  deferred_courses: string[];
  content_hash: string;
  version: number;
  assigned_by?: string | null;
  assignment_deadline?: string | null;
  manager_notes?: string | null;
  created_at: string;
  updated_at?: string | null;
  disclaimer: string;
}

export interface EmployeeSkill {
  skill_id: string;
  skill: string;
  self_assessed_level: number;
  verified_level: number | null;
  assessment_source?: string;
  updated_at?: string;
}

export interface LearningPreferences {
  preferred_learning_style: string;
  daily_study_hours: number;
  weekly_hours_available: number;
  training_intensity: string;
  budget_limit: number;
  target_completion_date?: string | null;
  wants_certificate?: boolean;
  preferred_certificate_type?: CertificateType | null;
  preferred_platforms?: string[];
}

export interface EmployeeProfile {
  employee_id: string;
  employee_code?: string;
  name: string;
  department: string;
  target_role: string;
  preferences: LearningPreferences;
  skills: EmployeeSkill[];
  completed_course_ids: string[];
}

export interface SkillGapItem {
  skill: string;
  current_proficiency: number;
  target_proficiency: number;
  gap: number;
  has_catalogue_courses: boolean;
  recommended_course_ids: string[];
}

export interface SkillGapAnalysisResponse {
  employee_id: string;
  target_role: string;
  gaps: SkillGapItem[];
  total_gaps: number;
  unfulfillable_skills: string[];
  role_competency_available: boolean;
  notes?: string | null;
}

export interface LearningProgressItem {
  progress_id: string;
  employee_id: string;
  course_id: string;
  lesson_id: string;
  status: string;
  time_spent_minutes: number;
  completed_at?: string;
  updated_at: string;
}

export interface QuizQuestion {
  question_id: string;
  prompt: string;
  options: string[];
  correct_option_index: number;
}

export interface CourseQuiz {
  assessment_id: string;
  skill_id: string;
  level: number;
  max_score: number;
  passing_score: number;
  rubric: string;
  questions: QuizQuestion[];
}

export interface AssessmentResult {
  assessment_id: string;
  employee_id: string;
  course_id: string;
  skill_id: string;
  score: number;
  max_score: number;
  passed: boolean;
  rubric_version: string;
  evidence: string;
  updated_verified_level?: number | null;
  created_at: string;
}

export interface ChatMessage {
  message_id: string;
  conversation_id: string;
  employee_id: string;
  sender: 'user' | 'assistant';
  message: string;
  course_id?: string;
  citations: Array<{
    chunk_id: string;
    document: string;
    section: string;
    score: number;
  }>;
  created_at: string;
}

export interface ChatConversation {
  conversation_id: string;
  employee_id: string;
  course_id?: string | null;
  title: string;
  created_at: string;
  updated_at: string;
}

export interface TeamMemberSummary {
  employee_id: string;
  name: string;
  department: string;
  email: string;
  has_active_assigned_plan: boolean;
  assigned_role?: string | null;
  assigned_deadline?: string | null;
  assigned_progress_percent: number;
  completed_courses_count: number;
}

export interface DashboardResponse {
  employee: EmployeeProfile;
  active_courses_count: number;
  completed_courses_count: number;
  overall_progress_percent: number;
  study_hours_this_week: number;
  next_recommended_task?: {
    course_id: string;
    title: string;
    skill: string;
    hours: number;
    action: string;
  } | null;
  recent_activity: Array<{
    type: string;
    description: string;
    timestamp: string;
  }>;
  self_directed_plan?: LearningPlan | null;
  company_assigned_plan?: LearningPlan | null;
  active_plan?: LearningPlan | null;
  skill_summary: Array<{
    skill: string;
    self: number;
    verified: number;
  }>;
}

const TOKEN_KEY = 'learning_agent_auth_token';

export const tokenStorage = {
  getToken: (): string | null => {
    try {
      return localStorage.getItem(TOKEN_KEY);
    } catch {
      return null;
    }
  },
  setToken: (token: string) => {
    try {
      localStorage.setItem(TOKEN_KEY, token);
    } catch {}
  },
  clearToken: () => {
    try {
      localStorage.removeItem(TOKEN_KEY);
    } catch {}
  }
};

function getAuthHeaders(empId?: string, isJson: boolean = false): Record<string, string> {
  const headers: Record<string, string> = {};
  if (isJson) {
    headers['Content-Type'] = 'application/json';
  }
  const token = tokenStorage.getToken();
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }
  if (empId) {
    headers['x-employee-id'] = empId;
  }
  return headers;
}

export const api = {
  // Auth API
  async register(payload: {
    email: string;
    password: string;
    name: string;
    role?: UserRole;
    is_employee?: boolean;
    employee_id?: string;
    department?: string;
  }): Promise<AuthTokenResponse> {
    const res = await fetch(`${API_BASE_URL}/auth/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ detail: 'Registration failed' }));
      throw new Error(err.detail || 'Registration failed');
    }
    const data: AuthTokenResponse = await res.json();
    if (data.token) {
      tokenStorage.setToken(data.token);
    }
    return data;
  },

  async login(payload: { email: string; password: string }): Promise<AuthTokenResponse> {
    const res = await fetch(`${API_BASE_URL}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ detail: 'Login failed' }));
      throw new Error(err.detail || 'Login failed');
    }
    const data: AuthTokenResponse = await res.json();
    if (data.token) {
      tokenStorage.setToken(data.token);
    }
    return data;
  },

  async getMe(): Promise<UserProfile> {
    const res = await fetch(`${API_BASE_URL}/auth/me`, {
      headers: getAuthHeaders()
    });
    if (!res.ok) {
      tokenStorage.clearToken();
      throw new Error('Unauthorized');
    }
    return res.json();
  },

  async logout(): Promise<void> {
    try {
      await fetch(`${API_BASE_URL}/auth/logout`, {
        method: 'POST',
        headers: getAuthHeaders()
      });
    } finally {
      tokenStorage.clearToken();
    }
  },

  async getDemoUsers(): Promise<UserProfile[]> {
    const res = await fetch(`${API_BASE_URL}/auth/users`, {
      headers: getAuthHeaders()
    });
    return res.json();
  },

  // Dashboard & Profiles
  async getDashboard(empId?: string): Promise<DashboardResponse> {
    const res = await fetch(`${API_BASE_URL}/dashboard`, {
      headers: getAuthHeaders(empId)
    });
    if (!res.ok) {
      throw new Error(`Failed to load dashboard: ${res.statusText}`);
    }
    return res.json();
  },

  async getProfile(empId?: string): Promise<EmployeeProfile> {
    const res = await fetch(`${API_BASE_URL}/employees/me`, {
      headers: getAuthHeaders(empId)
    });
    if (!res.ok) {
      throw new Error(`Failed to load profile: ${res.statusText}`);
    }
    return res.json();
  },

  async updateProfile(empId: string, payload: any): Promise<EmployeeProfile> {
    const res = await fetch(`${API_BASE_URL}/employees/me`, {
      method: 'PUT',
      headers: getAuthHeaders(empId, true),
      body: JSON.stringify(payload)
    });
    return res.json();
  },

  // Roles & Competencies
  async getRoles(): Promise<Role[]> {
    const res = await fetch(`${API_BASE_URL}/roles`, {
      headers: getAuthHeaders()
    });
    return res.json();
  },

  async createRole(payload: {
    role_name: string;
    description: string;
    prerequisites?: string[];
    relevant_resources?: string[];
    competencies: RoleCompetency[];
  }): Promise<Role> {
    const res = await fetch(`${API_BASE_URL}/roles`, {
      method: 'POST',
      headers: getAuthHeaders(undefined, true),
      body: JSON.stringify(payload)
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ detail: 'Role creation failed' }));
      throw new Error(err.detail || 'Role creation failed');
    }
    return res.json();
  },

  async updateRole(roleName: string, payload: any): Promise<Role> {
    const res = await fetch(`${API_BASE_URL}/roles/${encodeURIComponent(roleName)}`, {
      method: 'PUT',
      headers: getAuthHeaders(undefined, true),
      body: JSON.stringify(payload)
    });
    return res.json();
  },

  // Course Catalogue & Multi-Platform Discovery
  async getCourses(skill?: string, maxCost?: number): Promise<Course[]> {
    const params = new URLSearchParams();
    if (skill) params.append('skill', skill);
    if (maxCost !== undefined) params.append('max_cost', maxCost.toString());
    const res = await fetch(`${API_BASE_URL}/courses?${params.toString()}`, {
      headers: getAuthHeaders()
    });
    return res.json();
  },

  async discoverCourses(params: {
    query?: string;
    platform?: string;
    skill?: string;
    pricing_model?: string;
    certificate_type?: string;
    verification_status?: string;
    max_budget?: number;
  }): Promise<Course[]> {
    const urlParams = new URLSearchParams();
    if (params.query) urlParams.append('query', params.query);
    if (params.platform) urlParams.append('platform', params.platform);
    if (params.skill) urlParams.append('skill', params.skill);
    if (params.pricing_model) urlParams.append('pricing_model', params.pricing_model);
    if (params.certificate_type) urlParams.append('certificate_type', params.certificate_type);
    if (params.verification_status) urlParams.append('verification_status', params.verification_status);
    if (params.max_budget !== undefined) urlParams.append('max_budget', params.max_budget.toString());
    const res = await fetch(`${API_BASE_URL}/courses/discover?${urlParams.toString()}`, {
      headers: getAuthHeaders()
    });
    return res.json();
  },

  async getCourse(courseId: string): Promise<Course> {
    const res = await fetch(`${API_BASE_URL}/courses/${courseId}`, {
      headers: getAuthHeaders()
    });
    return res.json();
  },

  async getCourseQuiz(courseId: string, moduleId?: string): Promise<CourseQuiz> {
    const url = moduleId 
      ? `${API_BASE_URL}/courses/${courseId}/quiz?module_id=${encodeURIComponent(moduleId)}`
      : `${API_BASE_URL}/courses/${courseId}/quiz`;
    const res = await fetch(url, {
      headers: getAuthHeaders()
    });
    return res.json();
  },

  // Skill Gap Analysis
  async analyzeSkillGaps(empId: string, targetRole: string): Promise<SkillGapAnalysisResponse> {
    const res = await fetch(`${API_BASE_URL}/skill-gaps/analyze`, {
      method: 'POST',
      headers: getAuthHeaders(empId, true),
      body: JSON.stringify({ employee_id: empId, target_role: targetRole })
    });
    return res.json();
  },

  // Dual-Mode Learning Plans
  async generateRoadmap(
    empId: string, 
    targetRole: string, 
    budget?: number, 
    weeklyHours?: number,
    mode: PlanMode = 'self_directed',
    trainingIntensity: string = 'normal',
    wantsCertificate: boolean = false
  ): Promise<LearningPlan> {
    const res = await fetch(`${API_BASE_URL}/learning-plans/generate`, {
      method: 'POST',
      headers: getAuthHeaders(empId, true),
      body: JSON.stringify({
        employee_id: empId,
        target_role: targetRole,
        budget: budget,
        weekly_hours: weeklyHours,
        mode: mode,
        training_intensity: trainingIntensity,
        wants_certificate: wantsCertificate
      })
    });
    return res.json();
  },

  async getSelfDirectedPlan(empId: string): Promise<LearningPlan | null> {
    const res = await fetch(`${API_BASE_URL}/learning-plans/self-directed`, {
      headers: getAuthHeaders(empId)
    });
    if (!res.ok) return null;
    return res.json();
  },

  async getCompanyAssignedPlan(empId: string): Promise<LearningPlan | null> {
    const res = await fetch(`${API_BASE_URL}/learning-plans/company-assigned`, {
      headers: getAuthHeaders(empId)
    });
    if (!res.ok) return null;
    return res.json();
  },

  async createCustomGoal(payload: {
    employee_id: string;
    goal_title: string;
    goal_description?: string;
    target_skills: Record<string, number>;
    budget?: number;
    weekly_hours?: number;
  }): Promise<LearningPlan> {
    const res = await fetch(`${API_BASE_URL}/learning-plans/custom-goal`, {
      method: 'POST',
      headers: getAuthHeaders(payload.employee_id, true),
      body: JSON.stringify(payload)
    });
    return res.json();
  },

  async assignCompanyGoal(payload: {
    employee_id: string;
    target_role: string;
    assignment_deadline: string;
    budget: number;
    weekly_hours: number;
    manager_notes?: string;
  }, managerId?: string): Promise<LearningPlan> {
    const res = await fetch(`${API_BASE_URL}/learning-plans/assign-company-goal`, {
      method: 'POST',
      headers: getAuthHeaders(managerId || 'M1001', true),
      body: JSON.stringify(payload)
    });
    return res.json();
  },

  async getPlanHistory(empId: string): Promise<LearningPlan[]> {
    const res = await fetch(`${API_BASE_URL}/learning-plans/history`, {
      headers: getAuthHeaders(empId)
    });
    return res.json();
  },

  async getCurrentPlan(empId: string): Promise<LearningPlan | null> {
    const res = await fetch(`${API_BASE_URL}/learning-plans/current`, {
      headers: getAuthHeaders(empId)
    });
    if (!res.ok) return null;
    return res.json();
  },

  async updateCurrentPlan(empId: string, budget?: number, weeklyHours?: number): Promise<LearningPlan> {
    const res = await fetch(`${API_BASE_URL}/learning-plans/current`, {
      method: 'PUT',
      headers: getAuthHeaders(empId, true),
      body: JSON.stringify({ budget, weekly_hours: weeklyHours })
    });
    return res.json();
  },

  // Progress & Rubric Assessments
  async recordProgress(empId: string, courseId: string, lessonId: string, status: string, timeSpentMinutes: number): Promise<LearningProgressItem> {
    const res = await fetch(`${API_BASE_URL}/learning-progress`, {
      method: 'POST',
      headers: getAuthHeaders(empId, true),
      body: JSON.stringify({
        employee_id: empId,
        course_id: courseId,
        lesson_id: lessonId,
        status: status,
        time_spent_minutes: timeSpentMinutes
      })
    });
    return res.json();
  },

  async getProgress(empId: string, courseId?: string): Promise<LearningProgressItem[]> {
    const url = courseId ? `${API_BASE_URL}/learning-progress?course_id=${courseId}` : `${API_BASE_URL}/learning-progress`;
    const res = await fetch(url, {
      headers: getAuthHeaders(empId)
    });
    return res.json();
  },

  async submitAssessment(empId: string, courseId: string, assessmentId: string, answers: Record<string, number>): Promise<AssessmentResult> {
    const res = await fetch(`${API_BASE_URL}/assessments`, {
      method: 'POST',
      headers: getAuthHeaders(empId, true),
      body: JSON.stringify({
        employee_id: empId,
        course_id: courseId,
        assessment_id: assessmentId,
        answers: answers
      })
    });
    return res.json();
  },

  async getAssessments(empId: string): Promise<AssessmentResult[]> {
    const res = await fetch(`${API_BASE_URL}/assessments`, {
      headers: getAuthHeaders(empId)
    });
    return res.json();
  },

  // Chatbot
  async getChatConversations(empId: string): Promise<ChatConversation[]> {
    const res = await fetch(`${API_BASE_URL}/chat/conversations`, {
      headers: getAuthHeaders(empId)
    });
    return res.json();
  },

  async createChatConversation(empId: string, courseId?: string): Promise<ChatConversation> {
    const res = await fetch(`${API_BASE_URL}/chat/conversations`, {
      method: 'POST',
      headers: getAuthHeaders(empId, true),
      body: JSON.stringify({ employee_id: empId, course_id: courseId })
    });
    return res.json();
  },

  async sendChatMessage(
    empId: string, 
    message: string, 
    courseId?: string, 
    conversationId?: string,
    planMode: PlanMode = 'self_directed'
  ): Promise<any> {
    const convId = conversationId || `CONV-${Date.now()}`;
    const res = await fetch(`${API_BASE_URL}/chat/conversations/${convId}/messages`, {
      method: 'POST',
      headers: getAuthHeaders(empId, true),
      body: JSON.stringify({
        employee_id: empId,
        message: message,
        course_id: courseId,
        plan_mode: planMode
      })
    });
    return res.json();
  },

  async getChatHistory(conversationId: string): Promise<ChatMessage[]> {
    const res = await fetch(`${API_BASE_URL}/chat/conversations/${conversationId}/messages`, {
      headers: getAuthHeaders()
    });
    return res.json();
  },

  // Manager & Admin
  async getTeamOverview(): Promise<TeamMemberSummary[]> {
    const res = await fetch(`${API_BASE_URL}/manager/team`, {
      headers: getAuthHeaders()
    });
    return res.json();
  },

  async triggerImport(): Promise<any> {
    const res = await fetch(`${API_BASE_URL}/admin/import`, { 
      method: 'POST',
      headers: getAuthHeaders()
    });
    return res.json();
  }
};
